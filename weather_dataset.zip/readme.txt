数据从www.tianqi.com网站采集
分布式采集系统（爬虫）的客户端见我的Github：https://github.com/xiangwentao666/DistributedWeatherScrawller-Python-EXE-FILE
分布式采集系统（爬虫）的服务端见我的Github：https://github.com/xiangwentao666/DistributedWeatherScrawller-Java-Server

weather_info_cityyearaveragemax_chn
	是全国每个地方（市、区、县等）2011-2021年每年的平均最高温度（注：部分城市、部分年份的天气数据在网站www.tianqi.com不存在）
	eg: aba 2011 13.7679180887372   表示aba这个地方2011年的年平均最高温度为13.7679180887372

weather_info_cityyearaveragemin_chn
	是全国每个地方（市、区、县等）2011-2021年每年的平均最低温度（注：部分城市、部分年份的天气数据在网站www.tianqi.com不存在）
	eg: aba 2011 13.7679180887372   表示aba这个地方2011年的年平均最低温度为13.7679180887372

weather_info_directiontype_count_chn
	是全国每个地方（市、区、县等）2011-2021年每年的各类型风向的天数（注：部分城市、部分年份的天气数据在网站www.tianqi.com不存在）
	eg: aba 2011 西北风~西南风 2    表示aba这个地方2011年中风向类型为“西北风~西南风”的天数为2天

weather_info_monthlyaveragemaxmin_chn
	是全国每个地方（市、区、县等）2011-2021年每个月的平均最高、最低气温数据（注：部分城市、部分年份的天气数据在网站www.tianqi.com不存在）
	eg: aba 2011 3 6.65 -8.94  表示aba这个地方2011年3月的平均最高气温为6.65度、该月平均最低气温为-8.94度

weather_info_sunnydays_count_chn
	是全国每个地方（市、区、县等）2011-2021年每年中天气类型为“晴天”的天数（注：部分城市、部分年份的天气数据在网站www.tianqi.com不存在）
	eg: aba 2016 186    表示aba这个地方2016年中天气类型为“晴天”的天数为186天

weather_info_type_sum_chn
	是全国每个地方（市、区、县等）2011-2021年每年中各种天气类型的天数（注：部分城市、部分年份的天气数据在网站www.tianqi.com不存在）
	eg: aba 多云~小雪 24        表示aba这个地方2011年-2021年之间天气类型为“多云~小雪”的天数为24天
	